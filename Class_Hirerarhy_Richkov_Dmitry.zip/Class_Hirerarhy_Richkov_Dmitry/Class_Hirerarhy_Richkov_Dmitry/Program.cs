﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Hirerarhy_Richkov_Dmitry
{
    class Program
    {
        public const int SIZE = 3;
        static void Main(string[] args)
        {

            Autmobile[] array = new Autmobile[] { new Car("Corolla", 210, 150, "Sedan", "Automatic"), new Truck(1500, "TGX", 120, 400), new PublicTransport(30, "Next", 110, 210) };
            for(int i = 0; i < SIZE; i++)
            {
                Console.WriteLine(array[i]);
                Console.ReadLine();
            }
        }
    }
}
