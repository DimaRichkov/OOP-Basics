﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Hirerarhy_Richkov_Dmitry
{
    abstract class Autmobile
    {
        public string model;
        public string color;
        public int speed;
        public int power;
        public abstract void EngineStart();
        public abstract void Acceleration();
        public abstract void Brake();

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Model: " + this.model);
            sb.Append("; Speed: " + this.speed);
            sb.Append("; Power: " + this.power);
            return sb.ToString();
        }
    }
}
