﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Hirerarhy_Richkov_Dmitry
{
    class Car : Autmobile
    {
        private string bodyType;
        private string transmission;

        public Car(string model, int speed, int power, string bodyType, string transmission)
        {
            this.model = model;
            this.speed = speed;
            this.power = power;
            this.bodyType = bodyType;
            this.transmission = transmission;
        }

        public string BodyType
        {
            get
            {
                return bodyType;
            }

            set
            {
                bodyType = value;
            }
        }

        public string Transmission
        {
            get
            {
                return transmission;
            }

            set
            {
                transmission = value;
            }
        }

        public override void Acceleration()
        {
            throw new NotImplementedException();
        }

        public override void Brake()
        {
            throw new NotImplementedException();
        }

        public override void EngineStart()
        {
            throw new NotImplementedException();
        }

        public override string ToString()
        {
            return base.ToString() + "; Body type: " + bodyType.ToString() + "; Transmission: " + transmission.ToString();
        }
    }
}
