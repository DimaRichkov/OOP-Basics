﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Hirerarhy_Richkov_Dmitry
{
    class PublicTransport : Autmobile
    {
        private int numberOfSeats;

        public int NumberOfSeats
        {
            get
            {
                return numberOfSeats;
            }

            set
            {
                numberOfSeats = value;
            }
        }

        public PublicTransport(int numberOfSeats, string model, int speed, int power)
        {
            this.numberOfSeats = numberOfSeats;
            this.model = model;
            this.speed = speed;
            this.power = power;
        }

        private void DoorOpen()
        {

        }

        private void DoorClose()
        {

        }

        public override void Acceleration()
        {
            throw new NotImplementedException();
        }

        public override void Brake()
        {
            throw new NotImplementedException();
        }

        public override void EngineStart()
        {
            throw new NotImplementedException();
        }

        public override string ToString()
        {
            return base.ToString() + "; NumberOfSeats :" + NumberOfSeats.ToString();
        }
    }
}
